const dotenv = require("dotenv");
dotenv.config();
const express = require("express");
const cors = require("cors");
const db = require("./config/db");
const cookieParser = require("cookie-parser");
//Route
const userRouter = require("./routes/web/v1/user.route");
const adminRouter = require("./routes/web/v1/admin.route");
const productRouter = require("./routes/web/v1/product.route");
const chatRouter = require("./routes/web/v1/chatbot.route");
const cartRouter = require("./routes/web/v1/cart.routes");
const orderRouter = require("./routes/web/v1/order.routes")
const wishlistRouter = require("./routes/web/v1/wishlist.route")


const app = express();

app.use(express.json());
app.use(express.urlencoded({extended : true}));
app.use(cookieParser());
app.set(db());

// cors origin--> allow only that website that mention into origin group,ex.backend only res when localhost 3002 send request, other than give cors error
// localhost 3002 --> req --> accept --> give response
// localhost 3004 --> req --> cors error --> gont give response 
// in origin you mention frontend urls (devlopment, producation both)
app.use(cors({origin : "http://localhost:3002",credentials : true}));



PORT = process.env.PORT;
// temp route --> in backend we dont create a home route. teasting / devlopment remove home routes

app.get("/",(req,res)=>{
    res.status(401).json({message : "Access Denied!...."});
});
app.use("/user",userRouter);// localhost:3005/user/register

app.use("/admin",adminRouter); // --> url/admin/all/user

app.use("/product",productRouter);

app.use("/bot",chatRouter);

app.use("/cart",cartRouter);

app.use("/order" , orderRouter)

app.use("/wishlist",wishlistRouter);

app.listen(PORT, ()=>{
    console.log(`server is running on PORT ${PORT}`);
});